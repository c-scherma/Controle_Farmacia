package aux;
public class Funcionario {
    public Funcionario() {
        
    }
}
